import sys

print('The command line arguments are:')
print(sys.argv)

print('\npath is')
print(sys.path)
"""
a = 23
number = int(input('수를 입력하세요: '))

if a > number : 
  print('틀렸습니다. 조금 더 큰 수 입니다.')
elif a< number :
  print('틀렸습니다. 조금 더 작은 수 입니다.')
else:
  print('맞았습니다.')
"""
#========================================
"""
number = int(input('수를 입력하세요: '))

if number % 2 == 0 & number % 3 == 0:  
    print('짝수이면서 3의 배수입니다.')
elif number % 2 == 0:  
    print('짝수입니다.')
elif number % 3 == 0:  
    print('3의 배수입니다.')
"""
#========================================
"""
number = int(input('수를 입력하세요: '))
a = number + 20

if a>255:
 print('255')
elif a<0:
 print('0')
else:
 print(a)
"""
#========================================







import sys

print('The command line arguments are:')
print(sys.argv)

print('\n\nPATH is')
print(sys.path)
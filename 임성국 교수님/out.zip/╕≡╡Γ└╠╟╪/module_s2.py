import sys

print('The command line arguments are:')
for i in sys.argv:
    print(i)

print('\n\nPATH is')
for i in sys.path:
    print(i)
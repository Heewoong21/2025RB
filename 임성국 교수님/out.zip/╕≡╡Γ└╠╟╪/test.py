import module_name
print('test.py')

#copy con test.py(cmd)